﻿using System;
using System.Collections;

namespace Pet_Adoption_System_Project
{
    public class Animal
    {
        private string name;
        private string ID;
        private string type;
        private string breed;
        private string gender;
        private int age;
        private string status;

        public Animal(string id, string n, string t, string b, string g, int a)
        {
            ID = id;
            name = n;
            type = t;
            breed = b;
            gender = g;
            age = a;
            status = "Wait for adopted";
        }

        public string Name { get { return name; } }
        public string iD { get { return ID; } }
        public string Type { get { return type; } }
        public string Breed { get { return breed; } }
        public string Gender { get { return gender; } }
        public int Age { get { return age; } }
        public string Status { get { return status; } }

        public string updateStatus()
        {
            if (status == "Wait for adopted")
            {
                status = "Adopted";
            }
            else if (status == "Adopted")
            {
                status = "Wait for adopted";
            }
            return status;
        }

        public void getDetail()
        {
            Console.WriteLine(" ");
            Console.WriteLine("Name: " + name);
            Console.WriteLine("Type: " + type);
            Console.WriteLine("Breed: " + breed);
            Console.WriteLine("Gender: " + gender);
            Console.WriteLine("Age: " + age);
            Console.WriteLine("ID: " + iD);
            Console.WriteLine(" ");
        }
    }

    public class Adoption
    {
        private DateTime DateAdopted;
        private Animal animal;

        public Adoption(Animal a)
        {
            DateAdopted = DateTime.Now;
            animal = a;
        }

        public DateTime Date { get { return DateAdopted; } }

        public void updateStatus()
        {
            animal.updateStatus();
        }

        public void returnAnimal()
        {
            Console.WriteLine(" ");
            Console.WriteLine("Pet returned: ");
            animal.getDetail();
            Console.WriteLine("Date Adopted: " + DateAdopted);
            animal.updateStatus();
            Console.WriteLine("Pet status updated: " + animal.Status);
            Console.WriteLine("Successfully returned !");
            Console.WriteLine(" ");
        }
    }

    public class Adopter
    {
        private string phoneNumber;
        private string userName;
        private string email;
        private string password;
        private double income;
        private SortedList adoption = new SortedList();

        public Adopter(string ph, string un, string e, string p, double i)
        {
            phoneNumber = ph;
            userName = un;
            email = e;
            password = p;
            income = i;
        }

        public string Username { get { return userName; } }

        public void create(Animal animal)
        {
            Adoption a = new Adoption(animal);
            Tuple<Animal, Adoption> e = new Tuple<Animal, Adoption>(animal, a);
            adoption.Add(animal.iD, e);
        }

        public void returnAnimal()
        {
            for (int i = 0; i < adoption.Count; i++)
            {
                Tuple<Animal, Adoption> e = (Tuple<Animal, Adoption>)adoption.GetByIndex(i);
                e.Item2.returnAnimal();
                adoption.RemoveAt(i);
                i--;
            }
        }
    }
}
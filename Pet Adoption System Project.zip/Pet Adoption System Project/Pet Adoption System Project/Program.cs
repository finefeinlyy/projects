﻿using System.Collections;
using Pet_Adoption_System_Project;

SortedList animal = new SortedList();
SortedList adopter = new SortedList();

Console.WriteLine("Welcome to Pet Adoption System !");
Console.WriteLine("1. Pet registration ");
Console.WriteLine("2. Adopter registration ");
Console.WriteLine("3. Find a pet ");
Console.WriteLine("4. Pet adoption ");
Console.WriteLine("5. Return adopted pet ");
Console.WriteLine("6. Exit ");
Console.Write("Please select the service you want: ");
int choice = Convert.ToInt32(Console.ReadLine());

string name, type, breed, gender, id, phonenumber, email, username, password;
int age, find = 0;
double salary;

do
{
    switch (choice)
    {
        case 1:
            try
            {
                Console.Write("Name: "); //se1
                name = Console.ReadLine();
                Console.Write("Type: ");
                type = Console.ReadLine();
                Console.Write("Breed: ");
                breed = Console.ReadLine();
                Console.Write("Gender (Male or Female) : ");
                gender = Console.ReadLine();
                Console.Write("Age: ");
                age = Convert.ToInt32(Console.ReadLine());
                Console.Write("ID: ");
                id = Console.ReadLine();

                    if (animal.ContainsKey(id))
                    {
                        Console.WriteLine("ID already exists in the system. Please check the information and enter it again.");
                    }
                    else
                    {
                        if (age >= 0 && age < 30)
                        {
                            if (gender == "Male" || gender == "Female")
                            {
                                animal.Add(id, new Animal(id, name, type, breed, gender, age));
                                Console.WriteLine("Registration successful!");
                            }
                            else { Console.WriteLine("This gender does not exist. Please enter the information again."); }
                        }
                        else { Console.WriteLine("Incorrect age. Please enter the information again."); }
                    }
                
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }
            break;

        case 2: //se2
            try
            {
                Console.Write("Phone number: ");
                phonenumber = Console.ReadLine();
                if (adopter.ContainsKey(phonenumber))
                {
                    Console.WriteLine("This phone number is already in use.");
                }
                else
                {
                    Console.Write("Name: ");
                    username = Console.ReadLine();
                    Console.Write("Email: ");
                    email = Console.ReadLine();
                    Console.Write("Password: ");
                    password = Console.ReadLine();
                    Console.Write("Salary: ");
                    salary = double.Parse(Console.ReadLine());

                    if (salary >= 0 && salary < 25000)
                    {
                        Console.WriteLine("Interested adopter does not meet the minimum income requirement.");
                    }
                    else if (salary >= 25000)
                    {
                        adopter.Add(phonenumber, new Adopter(phonenumber, username, email, password, salary));
                        Console.WriteLine("Registration successful!");
                    }
                    else
                    {
                        Console.WriteLine("Salary cannot be negative.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }
            break;

        case 3:
            try
            {
                Console.Write("Phone number: ");
                phonenumber = Console.ReadLine();
                if (adopter.ContainsKey(phonenumber))
                {
                    Console.WriteLine("Name: " + ((Adopter)adopter[phonenumber]).Username);
                    Console.WriteLine("Please fill in the characteristics of the animal that you want."); // se3
                    Console.Write("Type of animal: ");
                    type = Console.ReadLine();
                    Console.WriteLine("Breed (Can select up to three items) ");
                    Console.Write("1. ");
                    breed = Console.ReadLine();
                    Console.Write("2. ");
                    string breed2 = Console.ReadLine();
                    Console.Write("3. ");
                    string breed3 = Console.ReadLine();
                    Console.Write("Gender: ");
                    gender = Console.ReadLine();
                    for (int i = 0; i < animal.Count; i++)
                    {
                        if (((Animal)animal.GetByIndex(i)).Type == type && ((Animal)animal.GetByIndex(i)).Gender == gender && ((Animal)animal.GetByIndex(i)).Status == "Wait for adopted")
                        {
                            if (((Animal)animal.GetByIndex(i)).Breed == breed || ((Animal)animal.GetByIndex(i)).Breed == breed2 || ((Animal)animal.GetByIndex(i)).Breed == breed3)
                            {
                                ((Animal)animal.GetByIndex(i)).getDetail();
                                find++;
                            }
                        }
                    }
                    if (find == 0)
                    { Console.WriteLine("The pet you are looking for is not found."); }

                }
                else
                {
                    Console.WriteLine("Adopter information not found. Please register in the system first.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }
            break;

        case 4:
            try
            {
                Console.Write("Phone number: ");//se4
                phonenumber = Console.ReadLine();
                if (adopter.ContainsKey(phonenumber))
                {
                    Console.Write("ID of the pet you want: ");
                    id = Console.ReadLine();
                    if (animal.ContainsKey(id))
                    {
                        if (((Animal)animal[id]).Status == "Wait for adopted")
                        {
                            ((Adopter)adopter[phonenumber]).create(((Animal)animal[id]));
                            ((Animal)animal[id]).updateStatus();
                            Console.WriteLine("Adoption completed !");
                        }
                        else { Console.WriteLine("The pet you want is not currently up for adoption."); }
                    }
                    else { Console.WriteLine("The pet you are looking for is not found."); }
                }
                else { Console.WriteLine("Adopter information not found. Please register in the system first."); }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }
            break;

        case 5:
            try
            {
                Console.Write("Phone number: ");
                phonenumber = Console.ReadLine();
                if (adopter.ContainsKey(phonenumber))
                {
                    Console.Write("ID of the pet you want to return: ");
                    id = Console.ReadLine();
                    Console.Write("The reason for the return: ");
                    string reason = Console.ReadLine();
                    if (animal.ContainsKey(id))
                    {
                        if (((Animal)animal[id]).Status == "Adopted")
                        {
                            ((Adopter)adopter[phonenumber]).returnAnimal();
                            ((Animal)animal[id]).updateStatus();
                            ((Animal)animal[id]).updateStatus();
                            Console.WriteLine("The return is complete.");
                        }
                        else { Console.WriteLine("The pet you want to return is not currently adopted."); }
                    }
                    else { Console.WriteLine("The pet you are looking for is not found."); }
                }
                else { Console.WriteLine("Adopter information not found. Please register in the system first."); }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }
            break;

        case 6:
            Console.WriteLine("Exiting the Pet Adoption System. Goodbye!");
            break;

        default:
            Console.WriteLine("Invalid choice. Please select a valid option.");
            break;
    }
    Console.WriteLine("Welcome to Pet Adoption System !");
    Console.WriteLine("1. Pet registration ");
    Console.WriteLine("2. Adopter registration ");
    Console.WriteLine("3. Find a pet ");
    Console.WriteLine("4. Pet adoption ");
    Console.WriteLine("5. Return adopted pet ");
    Console.WriteLine("6. Exit ");
    Console.Write("Please select the service you want: ");
    choice = Convert.ToInt32(Console.ReadLine());
}
while (choice != 6);